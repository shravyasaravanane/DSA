/*
 * Linked List - Delete nodes with a given data D (Challenge 31)
 * Input : N, then N integers (the linked list), then D.
 * Output: the linked list after every node holding D is deleted.
 *
 * Sample: 6 / 7 9 8 8 4 2 / 8               -> Linked List:->7->9->4->2
 *         10 / 5 3 7 2 7 9 8 8 4 2 / 2      -> Linked List:->5->3->7->7->9->8->8->4
 */
#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};

struct node *head = NULL;

/* builds the linked list from the input */
void create()
{
    int i, n, value;
    struct node *p1 = NULL, *temp;

    scanf("%d", &n);
    for(i=0;i<n;i++)
    {
        scanf("%d", &value);
        temp = (struct node *)malloc(sizeof(struct node));
        temp->data = value;
        temp->next = NULL;

        if (head == NULL)
            head = temp;
        else
            p1->next = temp;
        p1 = temp;
    }
}

/* deletes every node whose data is equal to d */
void del()
{
    int d;
    struct node *p1, *p2;

    scanf("%d", &d);

    /* nodes to be deleted at the beginning of the list */
    while (head != NULL && head->data == d)
    {
        p1 = head;
        head = head->next;
        free(p1);
    }

    /* nodes to be deleted in the middle or at the end */
    p2 = head;
    while (p2 != NULL && p2->next != NULL)
    {
        if (p2->next->data == d)
        {
            p1 = p2->next;
            p2->next = p1->next;
            free(p1);
        }
        else
        {
            p2=p2->next;
        }
    }
}

void display()
{
    struct node *p1 = head;
    printf("Linked List:");
    while (p1 != NULL)
    {
        printf("->%d", p1->data);
        p1 = p1->next;
    }
    printf("\n");
}

int main()
{
    create();
    del();
    display();
    return 0;
}
