/*
 * Linked List - Fold the linked list (Challenge 38)
 * Input : N, then N integers.
 * Steps : 1. build the linked list
 *         2. find the middle with slow and fast pointers
 *         3. split the list into two halves
 *         4. reverse the second half
 *         5. merge the two halves alternately (first, second, first, ...)
 * Output: line 1 -> the list in original order
 *         line 2 -> the list after folding
 *
 * Sample: 16 / 1 3 4 7 9 11 13 14 18 19 23 24 56 32 98 17
 *   Link list data:1 3 4 7 9 11 13 14 18 19 23 24 56 32 98 17
 *   Link list data after fold:1 17 3 98 4 32 7 56 9 24 11 23 13 19 14 18
 */
#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};

/* adds a new node at the end of the list */
void create(struct node **head,int data)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    struct node *temp;
    newNode->data = data;
    newNode->next = NULL;

    if (*head == NULL)
    {
        *head = newNode;
        return;
    }
    temp = *head;
    while (temp->next != NULL)
        temp = temp->next;
    temp->next = newNode;
}

void print(struct node *head)
{
    struct node *temp = head;
    while (temp != NULL)
    {
        printf("%d", temp->data);
        if (temp->next != NULL)
            printf(" ");
        temp = temp->next;
    }
    printf("\n");
}

struct node *reverse(struct node *head)
{
    struct node *prev = NULL, *current = head, *next;
    while (current != NULL)
    {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    return prev;
}

void fold(struct node *head)
{
    struct node *slow, *fast, *second, *first, *t1, *t2;

    if (head == NULL || head->next == NULL)
        return;

    /* find the middle: slow ends at the last node of the first half */
    slow = head;
    fast = head->next;
    while (fast != NULL && fast->next != NULL)
    {
        slow = slow->next;
        fast = fast->next->next;
    }

    /* divide into two halves and reverse the second half */
    second = slow->next;
    slow->next = NULL;
    second = reverse(second);

    /* alternate merge of the first and second halves */
    first = head;
    while (first != NULL && second != NULL)
    {
        t1 = first->next;
        t2 = second->next;
        first->next = second;
        if (t1 != NULL)
            second->next = t1;
        first = t1;
        second = t2;
    }
}

int main()
{
    struct node *head = NULL;
    int i, n, value;

    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &value);
        create(&head, value);
    }

    printf("Link list data:");
    print(head);

    fold(head);

    printf("Link list data after fold:");
    print(head);

    return 0;
}
