/*
 * Doubly Linked List - Insertion at the beginning (Challenge 32)
 * Input : N, then N integers. Each element is inserted at the beginning
 *         of the doubly linked list.
 * Output: line 1 -> list in the forward direction (head to tail)
 *         line 2 -> list in the backward direction (tail to head)
 *
 * Sample: 4 / 1 2 3 4 ->
 *         4 3 2 1
 *         1 2 3 4
 */
#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node *next;
    struct Node *prev;
};

void insertStart(struct Node** head,int data)
{
    /* create a new node and assign its data value */
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->data = data;

    /* new node's next points to the current head, prev is NULL */
    newNode->next = *head;
    newNode->prev = NULL;

    /* the old head's prev points to the new node */
    if (*head != NULL)
        (*head)->prev = newNode;

    /* head now refers to the new node */
    *head = newNode;
}

int main()
{
    struct Node *head = NULL, *temp, *last = NULL;
    int i, n, value;

    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &value);
        insertStart(&head, value);
    }

    /* forward direction */
    temp = head;
    while (temp != NULL)
    {
        printf("%d", temp->data);
        if (temp->next != NULL)
            printf(" ");
        last = temp;
        temp = temp->next;
    }
    printf("\n");

    /* backward direction */
    temp = last;
    while (temp != NULL)
    {
        printf("%d", temp->data);
        if (temp->prev != NULL)
            printf(" ");
        temp = temp->prev;
    }
    printf("\n");

    return 0;
}
