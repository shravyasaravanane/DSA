/*
 * Linked List - Delete D nodes from the beginning (Level 1, Challenge 40)
 * Input : N, then N integers (the linked list), then D (number of
 *         nodes to delete from the beginning).
 * Output: the final linked list after the deletion.
 *
 * Sample: 4 / 9 77 12 6 / 2            -> Linked List:->12->6
 *         6 / 45 21 91 77 12 61 / 4    -> Linked List:->12->61
 */
#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};

struct node *head = NULL;

/* builds the linked list from the input */
void create()
{
    int i, n, value;
    struct node *p1 = NULL, *temp;

    scanf("%d", &n);
    for(i=0;i<n;i++)
    {
        scanf("%d", &value);
        temp = (struct node *)malloc(sizeof(struct node));
        temp->data = value;
        temp->next = NULL;

        if (head == NULL)
            head = temp;
        else
            p1->next = temp;
        p1 = temp;
    }
}

/* deletes the first d nodes of the list */
void del()
{
    int d;
    struct node *temp;

    scanf("%d", &d);
    while (d > 0 && head != NULL)
    {
        temp = head;
        head = head->next;
        free(temp);
        d--;
    }
}

void display()
{
    struct node *p1 = head;
    printf("Linked List:");
    while (p1 != NULL)
    {
        printf("->%d", p1->data);
        p1 = p1->next;
    }
    printf("\n");
}

int main()
{
    create();
    del();
    display();
    return 0;
}
