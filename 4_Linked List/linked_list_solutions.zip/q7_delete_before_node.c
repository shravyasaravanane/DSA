/*
 * Linked List - Delete all nodes before a given node (Level 1, Challenge 37)
 * Input : N, then N integers (the linked list), then the value of the node.
 * Output: all nodes before the given node are deleted and the remaining
 *         list is printed. If the node is not present, print
 *         "Invalid Node!" followed by the unchanged list.
 *
 * Sample: 4 / 9 77 12 6 / 12     -> Linked List:->12->6
 *         4 / 91 77 12 61 / 2    -> Invalid Node! Linked List:->91->77->12->61
 */
#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};

struct node *head = NULL;

/* builds the linked list from the input */
void create()
{
    int i, n, value;
    struct node *p1 = NULL, *temp;

    scanf("%d", &n);
    for(i=0;i<n;i++)
    {
        scanf("%d", &value);
        temp = (struct node *)malloc(sizeof(struct node));
        temp->data = value;
        temp->next = NULL;

        if (head == NULL)
            head = temp;
        else
            p1->next = temp;
        p1 = temp;
    }
}

/* deletes every node that comes before the node holding 'key' */
void del()
{
    int key;
    struct node *p1, *temp;

    scanf("%d", &key);

    /* search for the given node */
    p1 = head;
    while (p1 != NULL && p1->data != key)
        p1=p1->next;

    if (p1 == NULL)
    {
        printf("Invalid Node! ");
        return;
    }

    /* free all nodes before p1 and make p1 the new head */
    while (head != p1)
    {
        temp = head;
        head = head->next;
        free(temp);
    }
}

void display()
{
    struct node *p1 = head;
    printf("Linked List:");
    while (p1 != NULL)
    {
        printf("->%d", p1->data);
        p1=p1->next;
    }
    printf("\n");
}

int main()
{
    create();
    del();
    display();
    return 0;
}
