/*
 * Linked List - Delete alternate nodes (Level 1, Challenge 35)
 * Input : n (number of elements). The list is built with the values 1..n.
 * Output: the list after deleting every alternate node, starting from
 *         the second node (2nd, 4th, 6th ...), on a single line.
 *
 * Sample: 10 -> 1 3 5 7 9
 *         20 -> 1 3 5 7 9 11 13 15 17 19
 */
#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};

/* Reads n and inserts the values 1..n at the end of the list */
void insert_Data(struct node **head)
{
    int n;
    scanf("%d", &n);

    struct node *tail = NULL;
    for (int i = 1; i <= n; i++)
    {
        struct node *newNode = (struct node *)malloc(sizeof(struct node));
        newNode->data = i;
        newNode->next = NULL;

        if (*head == NULL)
            *head = newNode;
        else
            tail->next = newNode;
        tail = newNode;
    }
}

/* a = current node, b = a->next (the node to delete) */
void delete_Alt(struct node **head)
{
    struct node *a = *head;
    struct node *b;

    while (a != NULL && a->next != NULL)
    {
        b = a->next;       /* second node of the pair            */
        a->next = b->next; /* link a to the node after b          */
        free(b);           /* free b                              */
        a = a->next;       /* move a to its next node             */
    }
}

void display(struct node *head)
{
    struct node *temp = head;
    while (temp != NULL)
    {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int main()
{
    struct node *head = NULL;

    insert_Data(&head);
    delete_Alt(&head);
    display(head);

    return 0;
}
