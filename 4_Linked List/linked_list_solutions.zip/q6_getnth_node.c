/*
 * Linked List - GetNth() (Challenge 36)
 * Input : N, then N integers, then the index I.
 * Each input value is pushed at the front of the linked list, so the
 * list is stored in reverse order of the input.
 * Output: line 1 -> the linked list
 *         line 2 -> the data of the node at the given index
 *
 * The sample outputs count the index from 1 (first node = index 1):
 *   4 / 1 2 3 4 / 2         -> Linked list:-->4-->3-->2-->1
 *                              Node at index=2:3
 *   4 / 11 21 31 41 / 3     -> Linked list:-->41-->31-->21-->11
 *                              Node at index=3:21
 */
#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};

/* inserts a new node at the beginning of the list */
void push(struct node **head, int data)
{
    struct node *newNode = (struct node *)malloc(sizeof(struct node));
    newNode->data = data;
    newNode->next = *head;
    *head = newNode;
}

/* returns the data of the node at the given index (first node = 1),
   or -1 if the index is not in the list */
int GetNth(struct node* head,int index)
{
    int count = 1;
    struct node *current = head;

    while (current != NULL)
    {
        if (count == index)
            return current->data;
        count++;
        current = current->next;
    }
    return -1;
}

int main()
{
    struct node *head = NULL, *temp;
    int i, n, value, index;

    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &value);
        push(&head, value);
    }
    scanf("%d", &index);

    printf("Linked list:");
    temp = head;
    while (temp != NULL)
    {
        printf("-->%d", temp->data);
        temp = temp->next;
    }
    printf("\n");

    printf("Node at index=%d:%d\n", index, GetNth(head, index));
    return 0;
}
