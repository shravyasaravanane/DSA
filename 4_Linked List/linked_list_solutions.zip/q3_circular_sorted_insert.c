/*
 * Circular Linked List - Sorted insert (Challenge 33)
 * Input : n, then n integers. Every element is inserted into a circular
 *         linked list so that the list always stays sorted.
 * Output: the elements of the circular list on a single line.
 *
 * Sample: 6 / 10 20 30 45 34 56 -> 10 20 30 34 45 56
 *         6 / 1 2 11 12 56 90   -> 1 2 11 12 56 90
 */
#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node *next;
};

void sortedInsert(struct Node** head_ref, struct Node* new_node)
{
    struct Node *present = *head_ref;

    /* Case 1: the list is empty, the new node points to itself */
    if (present == NULL)
    {
        new_node->next = new_node;
        *head_ref = new_node;
    }
    /* Case 2: the new node goes at the beginning (before the head) */
    else if (present->data >= new_node->data)
    {
        /* find the last node */
        while (present->next != *head_ref)
            present = present->next;
        present->next = new_node;      /* last node points to new node */
        new_node->next = *head_ref;    /* new node points to old head  */
        *head_ref = new_node;          /* head is the new node         */
    }
    /* Case 3: the new node goes after the head, at its sorted place */
    else
    {
        while (present->next != *head_ref &&
               present->next->data < new_node->data)
        {
            present = present->next;
        }
        new_node->next = present->next;
        present->next = new_node;
    }
}

int main()
{
    struct Node *head = NULL, *temp;
    int i, n, value;

    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &value);
        struct Node *new_node = (struct Node *)malloc(sizeof(struct Node));
        new_node->data = value;
        new_node->next = NULL;
        sortedInsert(&head, new_node);
    }

    /* print the circular list once, starting from the head */
    if (head != NULL)
    {
        temp = head;
        do
        {
            printf("%d", temp->data);
            temp = temp->next;
            if (temp != head)
                printf(" ");
        } while (temp != head);
    }
    printf("\n");

    return 0;
}
