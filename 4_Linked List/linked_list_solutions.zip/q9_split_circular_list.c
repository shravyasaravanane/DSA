/*
 * Circular Linked List - Split into odd and even lists (Level 1, Challenge 39)
 * Input : n. The circular list is built with the values 1..n.
 * Output: the complete list, then the list of odd-position nodes,
 *         then the list of even-position nodes. Each one is a circular
 *         list printed from the head [h] back to [h].
 *
 * Sample: 6 ->
 *   Complete linked_list:
 *   [h]=>1=>2=>3=>4=>5=>6=>[h]
 *   Odd:
 *   [h]=>1=>3=>5=>[h]
 *   Even:
 *   [h]=>2=>4=>6=>[h]
 */
#include <stdio.h>
#include <stdlib.h>

struct n
{
    int data;
    struct n *next;
};

struct n *head = NULL;
struct n *tail = NULL;

/* adds a node at the end and keeps the list circular */
void insert(int data)
{
    struct n *temp = (struct n *)malloc(sizeof(struct n));
    temp->data = data;

    if (head == NULL)
    {
        head = temp;
        tail = temp;
    }
    else
    {
        tail->next = temp;
        tail = temp;
    }
    tail->next = head;
}

/* prints a circular list starting from its head h */
void display(struct n *h)
{
    printf("[h]=>");
    if (h != NULL)
    {
        struct n *p = h;
        do
        {
            printf("%d=>", p->data);
            p = p->next;
        } while (p != h);
    }
    printf("[h]\n");
}

int main()
{
    int i, n;
    struct n *p, *oddHead = NULL, *oddTail = NULL;
    struct n *evenHead = NULL, *evenTail = NULL;

    scanf("%d", &n);
    for (i = 1; i <= n; i++)
        insert(i);

    printf("Complete linked_list:\n");
    display(head);

    /* split: 1st, 3rd, 5th ... nodes go to the odd list,
       2nd, 4th, 6th ... nodes go to the even list */
    p = head;
    for (i = 1; i <= n; i++)
    {
        struct n *next = p->next;
        if (i % 2 == 1)
        {
            if (oddHead == NULL)
                oddHead = p;
            else
                oddTail->next = p;
            oddTail = p;
        }
        else
        {
            if (evenHead == NULL)
                evenHead = p;
            else
                evenTail->next = p;
            evenTail = p;
        }
        p = next;
    }

    /* make both lists circular again */
    if (oddTail != NULL)
        oddTail->next = oddHead;
    if (evenTail != NULL)
        evenTail->next = evenHead;

    printf("Odd:\n");
    display(oddHead);
    printf("Even:\n");
    display(evenHead);

    return 0;
}
