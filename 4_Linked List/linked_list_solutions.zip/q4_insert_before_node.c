/*
 * Linked List - Insert a new node before a given node (Challenge 34)
 * Input : N, then N integers (the linked list),
 *         then P (the node before which the new node is inserted),
 *         then X (the data of the new node).
 * Output: case 1 (P found)     -> the final linked list
 *         case 2 (P not found) -> "Node not found!" and then the list
 *
 * Sample: 4 / 115 210 116 110 / 116 / 17
 *           -> Linked List:->115->210->17->116->110
 *         4 / 15 20 16 10 / 25 / 17
 *           -> Node not found!
 *              Linked List:->15->20->16->10
 */
#include <stdio.h>
#include <stdlib.h>

struct node
{
    int data;
    struct node *next;
};

struct node *start = NULL;

/* builds the linked list from the input */
void create()
{
    int i, n, value;
    struct node *p1 = NULL, *temp;

    scanf("%d", &n);
    for(i=0;i<n;i++)
    {
        scanf("%d", &value);
        temp = (struct node *)malloc(sizeof(struct node));
        temp->data = value;
        temp->next = NULL;

        if (start == NULL)
            start = temp;
        else
            p1->next = temp;
        p1 = temp;
    }
}

/* inserts x before the node holding p; returns 1 if p was found */
int insertBefore(int p, int x)
{
    struct node *p1, *p2, *q;

    /* P is the first node: new node becomes the start */
    if (start != NULL && start->data == p)
    {
        p1 = (struct node *)malloc(sizeof(struct node));
        p1->data = x;
        p1->next = start;
        start = p1;
        return 1;
    }

    /* traverse until the node just before P is found */
    p2 = start;
    while (p2 != NULL && p2->next != NULL)
    {
        if (p2->next->data == p)
        {
            p1 = (struct node *)malloc(sizeof(struct node));
            p1->data = x;
            q = p2->next;
            p1->next = q;
            p2->next=p1;
            return 1;
        }
        p2 = p2->next;
    }
    return 0;
}

void display()
{
    struct node *p1 = start;
    printf("Linked List:");
    while (p1 != NULL)
    {
        printf("->%d", p1->data);
        p1 = p1->next;
    }
    printf("\n");
}

int main()
{
    int p, x;

    create();
    scanf("%d", &p);
    scanf("%d", &x);

    if (!insertBefore(p, x))
        printf("Node not found!\n");

    display();
    return 0;
}
